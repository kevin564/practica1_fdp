# practica1_fdp
practica 1 de fundamentos de programacion
